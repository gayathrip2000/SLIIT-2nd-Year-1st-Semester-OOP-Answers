package Question4;

public class FrontAirBag extends CarAirBag {

	FrontAirBag(){
		
	}
	
	@Override
	void airBagMotionDetection() {
		// TODO Auto-generated method stub
		System.out.println("Motion detection on for Front Air Bag");
	}

	@Override
	void airBagLightIndecator() {
		// TODO Auto-generated method stub
		System.out.println("Light Indicator on for Front Air Bag");
	}

}
