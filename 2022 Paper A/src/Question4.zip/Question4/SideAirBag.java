package Question4;

public class SideAirBag extends  CarAirBag{
	 
	SideAirBag(){
		
	}

	@Override
	void airBagMotionDetection() {
		// TODO Auto-generated method stub
		System.out.println("Motion detection on for Side Air Bag");
	}

	@Override
	void airBagLightIndecator() {
		// TODO Auto-generated method stub
		System.out.println("Light Indecator on for Side Air Bag");
	}

}
