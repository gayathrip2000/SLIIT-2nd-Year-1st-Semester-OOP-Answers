package Question4;

public abstract class CarAirBag {
	
	abstract void airBagMotionDetection();
	abstract void airBagLightIndecator();

}
